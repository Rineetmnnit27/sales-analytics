use Project;
SELECT COUNT(*) FROM customer_features;
SELECT * FROM customer_features LIMIT 5;

-- Loyal vs Discount-Only Customers
SELECT
    customer_segment,
    promo_dependency_segment,
    COUNT(*) AS customer_count,
    ROUND(AVG(final_loyalty_score), 3) AS avg_loyalty_score,
    ROUND(AVG(total_spend), 2) AS avg_spend,
    ROUND(AVG(avg_annual_frequency), 1) AS avg_frequency
FROM customer_features
GROUP BY customer_segment, promo_dependency_segment
ORDER BY avg_loyalty_score DESC;


-- Behavioral Patterns Predicting High Value

SELECT
    value_tier,
    ROUND(AVG(avg_previous_purchases), 1) AS avg_past_purchases,
    ROUND(AVG(avg_annual_frequency), 1) AS avg_frequency,
    ROUND(AVG(subscription_score), 3) AS avg_subscription,
    ROUND(AVG(avg_review_rating), 2) AS avg_rating,
    ROUND(AVG(final_loyalty_score), 3) AS avg_loyalty,
    ROUND(AVG(total_spend), 2) AS avg_spend,
    COUNT(*) AS total_customers
FROM customer_features
GROUP BY value_tier
ORDER BY avg_spend DESC;


-- Geographically Underlevered Markets
SELECT
    location,
    COUNT(*) AS total_customers,
    ROUND(AVG(total_spend), 2) AS avg_spend,
    ROUND(AVG(final_loyalty_score), 3) AS avg_loyalty,
    ROUND(AVG(discount_dependency_score), 3) AS avg_discount_dependency,
    SUM(CASE WHEN value_tier = 'Premium Value' THEN 1 ELSE 0 END) AS premium_customers,
    ROUND(
        100.0 * SUM(CASE WHEN value_tier = 'Premium Value' THEN 1 ELSE 0 END) / COUNT(*), 1
    ) AS premium_pct,
    (SELECT cf2.favorite_category
     FROM customer_features cf2
     WHERE cf2.location = cf.location
     GROUP BY cf2.favorite_category
     ORDER BY COUNT(*) DESC
     LIMIT 1) AS top_category
FROM customer_features cf
GROUP BY location
HAVING COUNT(*) >= 5
ORDER BY avg_spend DESC
LIMIT 20;


-- Restructuring the Promotional Strategy
SELECT
    promo_dependency_segment,
    value_tier,
    COUNT(*) AS customer_count,
    ROUND(AVG(total_spend), 2) AS avg_spend,
    ROUND(AVG(avg_annual_frequency), 1) AS avg_frequency,
    ROUND(AVG(final_loyalty_score), 3) AS avg_loyalty,
    ROUND(AVG(avg_review_rating), 2) AS avg_satisfaction
FROM customer_features
GROUP BY promo_dependency_segment, value_tier
ORDER BY promo_dependency_segment, avg_spend DESC;


-- Ideal Customer Profile
SELECT
    CASE
        WHEN age < 25 THEN '18-24'
        WHEN age < 35 THEN '25-34'
        WHEN age < 45 THEN '35-44'
        WHEN age < 55 THEN '45-54'
        ELSE '55+'
    END AS age_group,
    favorite_category,
    preferred_payment_method,
    preferred_shipping_type,
    satisfaction_flag,
    COUNT(*) AS customer_count,
    ROUND(AVG(total_spend), 2) AS avg_spend,
    ROUND(AVG(final_loyalty_score), 3) AS avg_loyalty,
    ROUND(AVG(avg_annual_frequency), 1) AS avg_orders_per_year
FROM customer_features
WHERE value_tier = 'Premium Value'
  AND promo_dependency_segment != 'Highly Promo Dependent'
GROUP BY age_group, favorite_category,
         preferred_payment_method, preferred_shipping_type, satisfaction_flag
ORDER BY avg_spend DESC
LIMIT 20;

